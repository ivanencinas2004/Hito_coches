import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ClasicosComponent } from './clasicos/clasicos.component';
import { InformacionComponent } from './informacion/informacion.component';
import { CatalogoComponent } from './catalogo/catalogo.component';
import { ContactanosComponent } from './contactanos/contactanos.component';

export const routes: Routes = [
  {path: '', component: HomeComponent },
  { path: 'informacion', component: InformacionComponent },
  { path: 'clasicos', component: ClasicosComponent },
  { path: 'catalogo', component: CatalogoComponent },
  { path: 'contactanos', component: ContactanosComponent },
  { path: '**', redirectTo: '' }
];
