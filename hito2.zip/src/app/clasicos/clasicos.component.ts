import { Component } from '@angular/core';

@Component({
  selector: 'app-clasicos',
  standalone: true,
  imports: [],
  templateUrl: './clasicos.component.html',
  styleUrl: './clasicos.component.css'
})
export class ClasicosComponent {

}
